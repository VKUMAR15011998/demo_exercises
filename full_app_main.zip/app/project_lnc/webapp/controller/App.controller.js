sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("projectlnc.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  