const cds = require("@sap/cds");
const { NOTFOUND } = require("dns");
const { run } = require("node:test");
const { Adani_Logistics_LRF_Master,
  Adani_Logistics_Packing_Doc,
  Adani_Logistics_Material_Desc, 
  Adani_Logistics_Check_List,
  Adani_Logistics_Draft,
  Adani_Logistics_Final,
  Adani_Logistics_Approval,
  Adani_Logistics_Delivery_Details,
  Adani_Logistics_FF_Ship_Details,
  Adani_Logistics_FF_Doc_Upload,
  Get_Adani_Logistics_LRF_Master,
  per_Adani_Logistics_LRF_Master,
  
  LrfTracker1
} = cds.entities("app.logistics");

module.exports["Logistics_Service"] = srv => {
  
  srv.on('MyAction', async(req)=>{
   
    let { maxID } = await SELECT.one `count(*) as maxID` .from (Adani_Logistics_LRF_Master).where `PO_Number=${1110}`;
    const   aTable =await SELECT.from (Adani_Logistics_LRF_Master).where({PO_Number:'1111'});
    
    return aTable;
  });
  srv.before("CREATE", "Get_Adani_Logistics_LRF_Master", async (req, res) => {
    let { maxID } =await SELECT.one `count(*) as maxID` .from (Adani_Logistics_LRF_Master).where `PO_Number=${req.data.PO_Number}`;
     if(maxID !==undefined){
        maxID++;
        const Temp_LRF_Number = "Temp-"+req.data.Project_ID+"-LRF-"+req.data.PO_Number+"-"+maxID;
        req.data.Lrf_No = Temp_LRF_Number;
        
      }  
      
  });

 
  // srv.on("UPDATE","Get_Adani_Logistics_LRF_Master", async (req, res) => {
    
  //   let returnData = await cds
  //     .transaction(req)
  //     .run([
  //       UPDATE(Adani_Logistics_LRF_Master)
  //       .set({
  //         "Submit_Flag":req.data.Submit_Flag,
  //         "Shipment_Type": req.data.Shipment_Type,
  //         "C20_HighCube": req.data.C20_HighCube,
  //         "C20_FlatRack": req.data.C20_FlatRack,
  //         "C20_OpenTop": req.data.C20_OpenTop,
  //         "C20_GeneralPurpose": req.data.C20_GeneralPurpose,
  //         "C40_HighCube": req.data.C40_HighCube,
  //         "C40_FlatRack": req.data.C40_FlatRack,
  //         "C40_OpenTop": req.data.C40_OpenTop,
  //         "C40_GeneralPurpose": req.data.C40_GeneralPurpose,
  //         "PO_Inco_Terms": req.data.PO_Inco_Terms,
  //         "Act_Incoterms": req.data.Act_Incoterms,
  //         "TypeOfVehicle": req.data.TypeOfVehicle,
  //         "TypeOfLoadPort": req.data.TypeOfLoadPort,
  //         "NameOfDisPort": req.data.NameOfDisPort,
  //         "Ship_Cont_Name": req.data.Ship_Cont_Name,
  //         "Ship_Cont_No": req.data.Ship_Cont_No,
  //         "Ship_Email_ID": req.data.Ship_Email_ID,
  //         "Version": req.data.Version,
  //         "Approval_Status": req.data.Approval_Status,
  //         "TotalNetWeight": req.data.TotalNetWeight,
  //         "TotalGrossWeight": req.data.TotalGrossWeight,
  //         "TotalPackage": req.data.TotalPackage,
  //         "Sp_Req": req.data.Sp_Req,
  //         "Remarks": req.data.Remarks,
  //         "To_PackingDoc":[{
  //           "mediaType":"image/png",
  //           "fileName":"File 1"
  //         }],
  //         "To_MaterialDesc":[{
  //             "PackageNo": 1,
  //             "HAZ_DG_Cargo": "YES",
  //             "Description": "Desc1",
  //             "Length": 12,
  //             "Width": 11,
  //             "Height": 13,
  //             "QtyInNumbers": 45,
  //             "PerPackNetWeight": 32,
  //             "PerPackGrossWeight": 45,
  //             "TypeOfPacking": "Pack1",
  //             "VolInCBM": 31223.00,
  //             "Stackable": "YES",
  //             "Remarks": "test Remark"
  //         },
  //         {
  //           "PackageNo": 2,
  //           "HAZ_DG_Cargo": "YES",
  //           "Description": "Desc1",
  //           "Length": 12,
  //           "Width": 11,
  //           "Height": 13,
  //           "QtyInNumbers": 45,
  //           "PerPackNetWeight": 32,
  //           "PerPackGrossWeight": 45,
  //           "TypeOfPacking": "Pack1",
  //           "VolInCBM": 31223.00,
  //           "Stackable": "YES",
  //           "Remarks": "test Remark"
  //       }],
  //       "To_CkeckList": [
  //         {
  //             "Check1": null,
  //             "Check1_type": null,
  //             "Check1_FileName": null,
  //             "Check1_url": null,
  //             "Check2": null,
  //             "Check2_type": null,
  //             "Check2FileName": null,
  //             "Check2_url": null,
  //             "Check3": null,
  //             "Check3_type": null,
  //             "Check3FileName": null,
  //             "Check3_url": null,
  //             "Check4": null,
  //             "Check5": null,
  //             "Check6": null
  //         }
  //     ],
  //     "To_Draft": [
  //         {
  //             "D_FileType": null,
  //             "D_FileName": null,
  //             "D_Url": null,
  //             "D_DocTyp": null
  //         }
  //     ],
  //     "To_Final": [
  //         {
  //             "F_FileType": null,
  //             "F_FileName": null,
  //             "F_Url": null,
  //             "F_DocTyp": null
  //         }
  //     ],
  //     "To_Approval": {
  //         "FF_Email": null,
  //         "CHA_Email": null,
  //         "Logistics_Email": null,
  //         "FF_Status": null,
  //         "CHA_Status": null,
  //         "logistics_Status": null,
  //         "FF_Comments": null,
  //         "CHA_Comments": null,
  //         "Logistics_Comments": null
  //     },
  //     "To_DeliveryDetails": {
  //         "Site_Address": null,
  //         "DContact_Person": null,
  //         "DContact_No": null,
  //         "DEmail_ID": null,
  //         "Ins_Pol_01": null,
  //         "Ins_Pol_No1": null,
  //         "Ins_Company1": null,
  //         "Pol_Exp_Date1": null,
  //         "Ins_Pol_02": null,
  //         "Ins_Pol_No2": null,
  //         "Ins_Company2": null,
  //         "Pol_Exp_Date2": null,
  //         "Ins_Pol_03": null,
  //         "Ins_Pol_No3": null,
  //         "Ins_Company3": null,
  //         "Pol_Exp_Date3": null
  //     },
  //     "To_FF_Shipment": {
  //         "lines_name": null,
  //         "Foriegn_Agent_Details": null,
  //         "Trans_Dir": null,
  //         "Vessel_Name": null,
  //         "Ship_Mode": null,
  //         "Courier_Name": null,
  //         "Docket_No": null,
  //         "Docket_Date": null,
  //         "Allocation_Date": null,
  //         "BL_No": null,
  //         "BL_Rel_Date": null,
  //         "ETD_Plan": null,
  //         "ETA_Plan": null,
  //         "Delivery_Date": null,
  //         "Arrival_Date": null
  //     },
  //     "To_FF_Documents": {
  //         "Uploaded_By": null,
  //         "FF_File_Type": null,
  //         "FF_File_Name": null,
  //         "FF_Url": null
  //     }
  //       })
  //       .where({Lrf_No :req.params[0].Lrf_No}),
  //     ])
  //     .then((resolve, reject) => {
  //       console.log("resolve:", resolve);
  //       console.log("reject:", reject);

  //       if (typeof resolve !== "undefined") {
  //         return req.data;
  //       } else {
  //         req.error(409, "Record Not Found");
  //       }
  //     })
  //     .catch(err => {
  //       console.log(err);
  //       req.error(500, "Error in Updating Record");
  //     });
  //   console.log("Before End", returnData);
  //   return returnData;
  // });
  

  srv.after("READ", "Update_Adani_Logistics_LRF_Master", async (req, res) => {
       //var data=await srv.read(Adani_Logistics_LRF_Master).where({LRF_Master_ID :res.data.LRF_Master_ID});
     var getTempData = await SELECT.one.from(Adani_Logistics_LRF_Master).where({LRF_Master_ID :res.data.LRF_Master_ID})
     
    
    if(getTempData.Submit_Flag=="YES" & getTempData.Lrf_No.includes('Temp')){
      req[0].Lrf_No=await req[0].Lrf_No.slice(5);
       
      var insertper=await INSERT.into(per_Adani_Logistics_LRF_Master).entries(req[0])
      
     //await this._insert_permanent_logistics (getTempData,res.data)
     
     //var getperRec=await cds.transaction(req).run(SELECT.from(per_Adani_Logistics_LRF_Master))
    }else if(getTempData.Submit_Flag=="YES" & !getTempData.Lrf_No.includes('Temp')){
      
      await this._update_permanent_logistics (getTempData,req[0])
      }
    });

    this._insert_permanent_logistics = async function (getrecords,resData) {
      
      var insertdata= await INSERT.into(per_Adani_Logistics_LRF_Master).entries(getrecords)
      await UPDATE(per_Adani_Logistics_LRF_Master)
        .set(resData)
        .where({LRF_Master_ID :getrecords.LRF_Master_ID})
        return await SELECT.from(per_Adani_Logistics_LRF_Master)
  }
  this._update_permanent_logistics = async function (getrecords,resData) {
      
    
    await UPDATE(per_Adani_Logistics_LRF_Master)
      .set(resData)
      .where({LRF_Master_ID :getrecords.LRF_Master_ID})
      return await SELECT.from(per_Adani_Logistics_LRF_Master)
}
srv.before('CREATE', 'Adani_Logistics_Packing_Doc', req => {
    console.log('Create called')
    console.log(JSON.stringify(req.data))
    req.data.url = `/odata/v4/logistics-/Adani_Logistics_Packing_Doc(${req.data.PackingID})/content`
})
srv.before('CREATE', 'Adani_Logistics_Draft', req => {
  console.log('Create called')
  console.log(JSON.stringify(req.data))
  req.data.url = `/odata/v4/logistics-/Adani_Logistics_Draft(${req.data.Draft_ID})/content`
})
srv.before('CREATE', 'Adani_Logistics_Final', req => {
  console.log('Create called')
  console.log(JSON.stringify(req.data))
  req.data.url = `/odata/v4/logistics-/Adani_Logistics_Final(${req.data.Final_ID})/content`
})
srv.before('CREATE', 'Adani_Logistics_Check_List', req => {
  console.log('Create called')
  console.log(JSON.stringify(req.data))
  req.data.url = `/odata/v4/logistics-/Adani_Logistics_Check_List(${req.data.Check_ID})/content`
})
      srv.before("READ", "LrfTracker", async (req, res) => {
        const {LRF_Master_ID}=await SELECT.from(per_Adani_Logistics_LRF_Master);
        
       var result= await SELECT.from(Adani_Logistics_LRF_Master).where(`LRF_Master_ID NOT IN (SELECT.from(per_Adani_Logistics_LRF_Master))`);
       //(LRF_Master_ID).NOT.IN(SELECT.from(per_Adani_Logistics_LRF_Master)).UNION(SELECT.from(per_Adani_Logistics_LRF_Master))
        return result;
      }),
      srv.on('READ','LrfTracker2', async (req, res) => {
        let result2={};
        const val1=await SELECT.from(per_Adani_Logistics_LRF_Master) .columns('LRF_Master_ID');
        const outputArray = val1.map(obj => obj.LRF_Master_ID);
        
      const val2=await SELECT.from(per_Adani_Logistics_LRF_Master)
        
        
          var result = await SELECT.from(Adani_Logistics_LRF_Master).where`LRF_Master_ID not in ${outputArray}`;
         
          oCombTable = [...val2, ...result];
          
          //result2.oCombTable;
         // await INSERT.into(LrfTracker1).entries(oCombTable)
        
        return oCombTable;
      })
      srv.on('myFunctionImport', async (req) => {
        // Custom logic for myFunctionImport
        const responseMessage = 'Hello from myFunctionImport!';
        
        // Set response headers
        //req.response.headers.set('Content-Type', 'text/plain');
    
        // Return the response message
        return responseMessage;
      });
    
};